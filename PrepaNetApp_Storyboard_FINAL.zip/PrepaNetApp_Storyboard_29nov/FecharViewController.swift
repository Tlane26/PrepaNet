//
//  FecharViewController.swift
//  PrepaNetApp_Storyboard
//
//  Created by Eduardo salazar on 28/11/22.
//

import UIKit
import Firebase

class FecharViewController: UIViewController {

    var Fcampus : String!
    var Fseccion : String!
    let db = Firestore.firestore()
    
    @IBOutlet weak var mesInicio: UITextField!
    @IBOutlet weak var diaInicio: UITextField!
    @IBOutlet weak var anInicio: UITextField!
    
    @IBOutlet weak var mesFin: UITextField!
    @IBOutlet weak var diaFin: UITextField!
    @IBOutlet weak var anFin: UITextField!
    
    @IBOutlet weak var guardarBtn: UIButton!
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.portrait
    }
    
    override var shouldAutorotate: Bool {
        return false
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func fecharAction(_ sender: UIButton) {
        if  self.mesInicio.text == "" || self.diaInicio.text == "" || self.anInicio.text == "" || self.anFin.text == "" || self.mesFin.text == "" || self.diaFin.text == "" {
            let alerta = UIAlertController(title: "Error", message: "Completa todos los campos", preferredStyle: .alert)
            
            let action = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            
            alerta.addAction(action)
            self.present(alerta, animated: true, completion: nil)
            
        }
        else{
                db.collection("Seccion").getDocuments { querySnapshot, error in
                    if let error = error {
                        print(error.localizedDescription)
                    }
                    else {
                        for document in querySnapshot!.documents {
                            let data = document.data()
                            
                            let Ecampus = data["campus"] as! String
                            // Checar que los inscritos sean de la seccion escogida
                            var Eseccion = data["ID"] as! String
                            // campus
                            if self.Fcampus == Ecampus && Eseccion == self.Fseccion{
                                let afin = Int(self.anFin.text!)
                                let mfin = Int(self.mesFin.text!)
                                let dfin =  Int(self.diaFin.text!)
                                let ain = Int(self.anInicio.text!)
                                let min = Int(self.mesInicio.text!)
                                let din =  Int(self.diaInicio.text!)
                                
                                self.db.collection("Seccion").document(document.documentID).updateData(["anioFinal": afin]) { error in
                                    if let error = error {
                                        print("Error updating aF: \(error)")
                                    } else {
                                        print("Document successfully updated!")
                                    }
                                }
                                self.db.collection("Seccion").document(document.documentID).updateData(["diaFinal": dfin]) { error in
                                    if let error = error {
                                        print("Error updating df: \(error)")
                                    } else {
                                        print("Document successfully updated!")
                                    }
                                }
                                self.db.collection("Seccion").document(document.documentID).updateData(["mesFinal": mfin]) { error in
                                    if let error = error {
                                        print("Error updating mi: \(error)")
                                    } else {
                                        print("Document successfully updated!")
                                    }
                                }
                                
                                self.db.collection("Seccion").document(document.documentID).updateData(["anioInicial": ain]) { error in
                                    if let error = error {
                                        print("Error updating ai: \(error)")
                                    } else {
                                        print("Document successfully updated!")
                                    }
                                }
                                self.db.collection("Seccion").document(document.documentID).updateData(["diaInicial": din]) { error in
                                    if let error = error {
                                        print("Error updating di: \(error)")
                                    } else {
                                        print("Document successfully updated!")
                                    }
                                }
                                self.db.collection("Seccion").document(document.documentID).updateData(["mesInicial": min]) { error in
                                    if let error = error {
                                        print("Error updating mi: \(error)")
                                    } else {
                                        print("Document successfully updated!")
                                    }
                                }
                            }
                        }
                    }
                }
        }
        //dismiss(animated: true)
    }
    
    @IBAction func backbutton(_ sender: UIButton) {
        dismiss(animated: true)
    }
}
