//
//  CoordViewController.swift
//  PrepaNetApp_Storyboard
//
//  Created by Eduardo salazar on 21/10/22.
//

import UIKit
import Firebase

class CoordViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    let db = Firestore.firestore()
    
    var listaTalleres = [Taller]()
    var listaSecciones = [Seccion]()
 
    var IdUsuario : QueryDocumentSnapshot!
    var campusCoord : String!
    var idSeccionSel : String!
    
    @IBOutlet weak var tableView: UITableView!
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.portrait
    }
    
    override var shouldAutorotate: Bool {
        return false
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Obtener el campus del coordinador
        // de esta forma se trae los talleres y alumnos del campus
        let data = IdUsuario.data()
        campusCoord = data["campus"] as? String
        
        
        getTalleres()
        getSecciones()
    }
    
    func getTalleres() {
        
        var arrTalleres = [Taller]()
        
        db.collection("Taller").getDocuments { querySnapshot, error in
            
            if let error = error {
                print(error.localizedDescription)
            }
            else {
                for document in querySnapshot!.documents {
                    let data = document.data()
                    let ident = document.documentID
                    let idTaller = data["ID"] as! String
                    let descripcion = data["descripcion"] as! String
                    let nombre = data["nombre"] as! String
                    let numTaller = data["numTaller"] as! Int
                    
                    let unTaller = Taller(ID: idTaller, nombre: nombre, descripcion: descripcion, numTaller: numTaller)
                    
                    arrTalleres .append(unTaller)
                }
                self.listaTalleres = arrTalleres
                self.tableView.reloadData()
            }
            
        }
        
    }
    
    func getSecciones() {
        
        var arrSecciones = [Seccion]()
        
        db.collection("Seccion").getDocuments { querySnapshot, error in
            
            if let error = error {
                print(error.localizedDescription)
            }
            else {
                for document in querySnapshot!.documents {
                    let data = document.data()
                    var campus = data["campus"] as! String
                    
                    // si el coordinador igual que el campus de la seccion se guarda en el arreglo
                    if self.campusCoord == campus {
                        let ident = document.documentID
                        let idSeccion = data["ID"] as! String
                        let idTaller = data["IDTaller"] as! Int
                        campus = data["campus"] as! String
                        let periodo = data["periodo"] as! String
                        let anioInicio = data["anioInicio"] as! Int
                        let mesInicio = data["mesInicio"] as! Int
                        let diaInicio = data["diaInicio"] as! Int
                        let anioFinal = data["anioFinal"] as! Int
                        let mesFinal = data["mesFinal"] as! Int
                        let diaFinal = data["diaFinal"] as! Int
                        
                        let unaSeccion = Seccion(ID: idSeccion, IDTaller: idTaller, periodo: periodo, campus: campus, añoInicio: anioInicio, mesInicio: mesInicio, diaInicio: diaInicio, añoFinal: anioFinal, mesFinal: mesFinal, diaFinal: diaFinal)
                        
                        arrSecciones.append(unaSeccion)
                    }
                    self.listaSecciones = arrSecciones
                    self.tableView.reloadData()
                }
            }
            
        }
        
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listaSecciones.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celdaSecciones", for: indexPath)
        
        cell.backgroundColor = UIColor(red: 0.082, green: 0.106, blue: 0.188, alpha: 1.0)
        
        cell.textLabel?.textColor = .white

        // Configure the cell...
        cell.textLabel?.text = listaSecciones[indexPath.row].ID
        //cell.detailTextLabel?.text = listaTalleres[indexPath.row].descripcion

        return cell
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        let vistaAlumnos = segue.destination as! CoordVerAlumViewController
        let indice = tableView.indexPathForSelectedRow
        vistaAlumnos.alumnoMostrar = listaSecciones[indice!.row]
        //vistaAlumnos.cantSecciones = listaSecciones.count
        vistaAlumnos.campusSeccion = self.campusCoord
        vistaAlumnos.idSeccionSel = listaSecciones[indice!.row].ID
        
        //let vistaAdmin = segue.destination as! AdminViewController
//        let indicedos = tableView.indexPathForSelectedRow
  //      vistaAdmin.listaSecciones = listaSecciones[indicedos!.row].ID
    
    }

}
