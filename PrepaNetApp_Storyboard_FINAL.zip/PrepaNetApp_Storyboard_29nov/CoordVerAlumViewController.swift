//
//  CoordVerAlumViewController.swift
//  PrepaNetApp_Storyboard
//
//  Created by untittle on 18/11/22.
//

import UIKit
import Firebase

class CoordVerAlumViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    let db = Firestore.firestore()
    
    var infoInscrito : QueryDocumentSnapshot?
    
    
    var alumnoMostrar : Seccion!
    //var cantSecciones : Int!
    var listaEstudiantes = [Estudiante]()
    var listaInscritos = [Inscritos]()
    
    var campusSeccion : String!
    var idSeccionSel : String!
    
    @IBOutlet weak var tableView: UITableView!
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.portrait
    }
    
    override var shouldAutorotate: Bool {
        return false
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        //getEstudiantes()
        getInscritos()
    }
    
    func getInscritos() {
        
        var arrInscritos = [Inscritos]()
        
        db.collection("Inscripcion").getDocuments { querySnapshot, error in
            
            if let error = error {
                print(error.localizedDescription)
            }
            else {
                for document in querySnapshot!.documents {
                    let data = document.data()
                    
                    let campus = data["campus"] as! String
                    // Checar que los inscritos sean del campus del coord
                    var seccion = data["seccion"] as! String
                    if self.campusSeccion == campus && seccion == self.idSeccionSel{
                        
                        let ident = document.documentID
                        let matEst = data["matEstudiante"] as! String
                         seccion = data["seccion"] as! String
                        let periodo = data["periodo"] as! String
                        let estatus = data["estatus"] as! String
                        let nombre = data["nombre"] as! String
                        let apellido = data["apellido"] as! String
                        let calificacion = data["calificacion"] as! String
                        
                        let unInscrito = Inscritos(matEstudiante: matEst, seccion: seccion, periodo: periodo, estatus: estatus, nombre: nombre, apellido: apellido, calificacion: calificacion)
                        
                        arrInscritos .append(unInscrito)
                        
                        self.infoInscrito = document
                    }
                    self.listaInscritos = arrInscritos
                    self.tableView.reloadData()
                    
                }
                
            }
            
        }
        
    }
    
    // MARK: - Table view data source

    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return listaInscritos.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celdaAlumnos", for: indexPath)
        
        cell.backgroundColor = UIColor(red: 0.082, green: 0.106, blue: 0.188, alpha: 1.0)
        
        cell.textLabel?.textColor = .white

        // Configure the cell...
        cell.textLabel?.text = listaInscritos[indexPath.row].nombre + " " + listaInscritos[indexPath.row].apellido
        //cell.textLabel?.text = "estudiante 1"
        //cell.detailTextLabel?.text = listaTalleres[indexPath.row].descripcion

        return cell
    }

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        
            let vistaPerfilAlumno = segue.destination as! CoordSecAlumPerfViewController
            vistaPerfilAlumno.infoEstudiante = infoInscrito
    }
    
    
    @IBAction func backbutton(_ sender: UIButton) {
        dismiss(animated: true)
    }
}
