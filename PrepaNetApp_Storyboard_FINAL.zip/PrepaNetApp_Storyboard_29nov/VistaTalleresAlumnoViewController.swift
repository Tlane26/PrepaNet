//
//  VistaTalleresAlumnoViewController.swift
//  PrepaNetApp_Storyboard
//
//  Created by untittle on 16/11/22.
//

import UIKit

class VistaTalleresAlumnoViewController: UIViewController {
    
    
    @IBOutlet weak var lbTitulo: UILabel!
    @IBOutlet weak var lbDescripcion: UILabel!
    @IBOutlet weak var lbFechaIni: UILabel!
    @IBOutlet weak var lbFechaFin: UILabel!
    @IBOutlet weak var botonInscribir: UIButton!
    @IBOutlet weak var estadoCurso: UILabel!
    
    var tallerMostrar : Taller!
    var seccionMostrar : Seccion!
    let arrMeses = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]
    var dispoibleAlumno : Bool!
    var aprobado : Int! // numero del ultimo curso aprobado
    var cursoIndice : Int!// numero del curso que se esta viendo
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.portrait
    }
    
    override var shouldAutorotate: Bool {
        return false
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        lbTitulo.text = tallerMostrar.nombre
        lbDescripcion.text = tallerMostrar.descripcion
        
        //asignarMes(arrMeses: arrMeses, mesInicio: seccionMostrar.mesInicio, mesFinal: seccionMostrar.mesFinal)
        
        lbFechaIni.text = String(seccionMostrar.diaInicio) + " de " + arrMeses[(seccionMostrar.mesInicio - 1)] + " de " + String(seccionMostrar.añoInicio)
        lbFechaFin.text = String(seccionMostrar.diaFinal) + " de " + arrMeses[(seccionMostrar.mesFinal - 1)] + " de " + String(seccionMostrar.añoFinal)
        
        
        if dispoibleAlumno {
            botonInscribir.isEnabled = true
        }
        else {
            botonInscribir.isEnabled = false
        }
        
        if aprobado <= cursoIndice{
            estadoCurso.text = "No aprobado"
        }
        else{
            estadoCurso.text = "Aprobado"
        }
        //lbFechaIni.text = String(seccionMostrar.diaInicio) + " de " + String(seccionMostrar.mesInicio) + " de " + String(seccionMostrar.añoInicio)
        //lbFechaFin.text = String(seccionMostrar.diaFinal) + " de " + String(seccionMostrar.mesFinal) + " de " + String(seccionMostrar.añoFinal)
        
    }
    
    /*func asignarMes(arrMeses: [String], mesInicio: Int, mesFinal: Int) {
        for i in 0 ..< 12 {
            if (mesInicio == 1) or (mesFinal == 1) {
                arrMeses[i] =
            }
        }
    }*/
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    
    @IBAction func inscribirCurso(_ sender: UIButton) {
        let vistaTab = presentingViewController as! UITabBarController
        let vista = vistaTab.viewControllers![0] as! AlumnoViewController
        botonInscribir.isEnabled = false
        vista.seInscribioCurso(curso: tallerMostrar.nombre)
        
        
        
        
        let alerta = UIAlertController(title: "Inscrito", message: "El curso ha sido inscrito correctamente", preferredStyle: .alert)
        
        let action = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        
        alerta.addAction(action)
        present(alerta, animated: true, completion: nil)
        
    }
    
    
}
