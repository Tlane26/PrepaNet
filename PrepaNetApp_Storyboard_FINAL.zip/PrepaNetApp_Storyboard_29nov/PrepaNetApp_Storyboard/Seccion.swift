//
//  Seccion.swift
//  PrepaNetApp_Storyboard
//
//  Created by Eduardo salazar on 21/10/22.
//

import UIKit

class Seccion: Codable {
    
    var ID : String
    var IDTaller : Int
    var periodo : String
    var campus : String
    var añoInicio : Int!
    var mesInicio : Int!
    var diaInicio : Int!
    var añoFinal : Int!
    var mesFinal : Int!
    var diaFinal : Int!
    
    init(ID: String, IDTaller: Int, periodo: String, campus: String, añoInicio: Int, mesInicio: Int, diaInicio: Int, añoFinal: Int, mesFinal: Int, diaFinal: Int) {
        self.ID = ID
        self.IDTaller = IDTaller
        self.periodo = periodo
        self.campus = campus
        self.añoInicio = añoInicio
        self.mesInicio = mesInicio
        self.diaInicio = diaInicio
        self.añoFinal = añoFinal
        self.mesFinal = mesFinal
        self.diaFinal = diaFinal
    }

}
