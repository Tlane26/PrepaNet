//
//  Taller.swift
//  PrepaNetApp_Storyboard
//
//  Created by Eduardo salazar on 21/10/22.
//

import UIKit

class Taller: Codable {
    
    var ID : String
    var nombre : String
    var descripcion : String
    var numTaller : Int
    
    init(ID: String, nombre: String, descripcion: String, numTaller: Int) {
        self.ID = ID
        self.nombre = nombre
        self.descripcion = descripcion
        self.numTaller = numTaller
    }

}
