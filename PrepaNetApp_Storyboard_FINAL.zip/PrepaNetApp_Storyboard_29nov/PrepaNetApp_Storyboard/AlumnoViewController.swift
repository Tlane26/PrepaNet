//
//  AlumnoViewController.swift
//  PrepaNetApp_Storyboard
//
//  Created by Eduardo salazar on 21/10/22.
//

import UIKit
import Firebase

class AlumnoViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    let db = Firestore.firestore()
    
    var listaTalleres = [Taller]()
    var listaSecciones = [Seccion]()
    var seccionesDispoibles = [Bool]()
    
    var IdUsuario : QueryDocumentSnapshot!
    
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var lblNombre: UILabel!
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.portrait
    }
    
    override var shouldAutorotate: Bool {
        return false
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let data = IdUsuario.data()
        lblNombre.text = "Hola " + (data["nombre"] as! String) + " " + (data["apellido"] as! String)
        seccionesDispoibles = data["seccion"] as! [Bool]
        
        getTalleres()
        getSecciones()
    }
    
    func getTalleres() {
        
        var arrTalleres = [Taller]()
        
        db.collection("Taller").getDocuments { querySnapshot, error in
            
            if let error = error {
                print(error.localizedDescription)
            }
            else {
                for document in querySnapshot!.documents {
                    let data = document.data()
                    let ident = document.documentID
                    let idTaller = data["ID"] as! String
                    let descripcion = data["descripcion"] as! String
                    let nombre = data["nombre"] as! String
                    let numTaller = data["numTaller"] as! Int
                    
                    let unTaller = Taller(ID: idTaller, nombre: nombre, descripcion: descripcion, numTaller: numTaller)
                    
                    arrTalleres .append(unTaller)
                }
                self.listaTalleres = arrTalleres
                self.tableView.reloadData()
            }
            
        }
        
    }
    
    func getSecciones() {
        
        var arrSecciones = [Seccion]()
        
        db.collection("Seccion").getDocuments { querySnapshot, error in
            
            if let error = error {
                print(error.localizedDescription)
            }
            else {
                for document in querySnapshot!.documents {
                    let data = document.data()
                    let ident = document.documentID
                    let idSeccion = data["ID"] as! String
                    let idTaller = data["IDTaller"] as! Int
                    let campus = data["campus"] as! String
                    let periodo = data["periodo"] as! String
                    let anioInicio = data["anioInicio"] as! Int
                    let mesInicio = data["mesInicio"] as! Int
                    let diaInicio = data["diaInicio"] as! Int
                    let anioFinal = data["anioFinal"] as! Int
                    let mesFinal = data["mesFinal"] as! Int
                    let diaFinal = data["diaFinal"] as! Int
                    
                    let unaSeccion = Seccion(ID: idSeccion, IDTaller: idTaller, periodo: periodo, campus: campus, añoInicio: anioInicio, mesInicio: mesInicio, diaInicio: diaInicio, añoFinal: anioFinal, mesFinal: mesFinal, diaFinal: diaFinal)
                    
                    arrSecciones .append(unaSeccion)
                }
                self.listaSecciones = arrSecciones
                self.tableView.reloadData()
            }
            
        }
        
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return listaTalleres.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }

    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        
        cell.backgroundColor = UIColor(red: 0.110, green: 0.157, blue: 0.435, alpha: 1.0)
        
        cell.textLabel?.textColor = .white

        // Configure the cell...
        cell.textLabel?.text = listaTalleres[indexPath.row].nombre
        //cell.detailTextLabel?.text = listaTalleres[indexPath.row].descripcion

        return cell
    }
    
    // MARK: - Prepare for segue
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        let vistaTalleres = segue.destination as! VistaTalleresAlumnoViewController
        let indice = tableView.indexPathForSelectedRow
        vistaTalleres.tallerMostrar = listaTalleres[indice!.row]
        vistaTalleres.seccionMostrar = listaSecciones[indice!.row]
        
        vistaTalleres.aprobado = cursosAprobados()
        vistaTalleres.cursoIndice = indice!.row
        print(indice!.row)
        if seccionesDispoibles[indice!.row] == true{
            vistaTalleres.dispoibleAlumno = true
        }
        else{
            vistaTalleres.dispoibleAlumno = false
        }
    }
    
    func cursosAprobados() -> Int{
        var indiceCurso = 0
        for i in seccionesDispoibles{
            if i == true{
                break
            }
            indiceCurso += 1
        }
        print(indiceCurso)
        return indiceCurso
        
    }
    
    func seInscribioCurso(curso : String){

        db.collection("Estudiante").document(IdUsuario.documentID).updateData(["cursoActual": curso]){ error in
            if let error = error {
                print("Error updating document: \(error)")
            } else {
                print("Document successfully updated!")
            }
        }

    }
    

}
