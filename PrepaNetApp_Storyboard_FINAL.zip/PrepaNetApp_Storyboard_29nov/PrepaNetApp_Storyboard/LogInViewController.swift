//
//  LogInViewController.swift
//  PrepaNetApp_Storyboard
//
//  Created by Eduardo salazar on 21/10/22.
//

import UIKit
import Firebase
import SwiftUI

class LogInViewController: UIViewController {

    let db = Firestore.firestore()
    
    var opc : Int?
    var idUsu : QueryDocumentSnapshot?
    
    @IBOutlet weak var tfEmail: UITextField!
    @IBOutlet weak var tfPassword: UITextField!
    @IBOutlet weak var btnCreditos: UIButton!
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.portrait
    }
    
    override var shouldAutorotate: Bool {
        return false
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func logInbuttonAction(_ sender: UIButton) {
        logInAdmin(){ [self] result in
            if result == "OK" {
                DispatchQueue.main.async(){
                    [unowned self] in
                    self.performSegue(withIdentifier: "logInAdmin", sender: nil)
                }
            }
            else{
                logInCoordi(){ [self] result in
                    if result == "OK" {
                        DispatchQueue.main.async(){
                            [unowned self] in
                            self.performSegue(withIdentifier: "logInCoord", sender: nil)
                        }
                    }
                    else{
                        logInAlumno(){ [self] result in
                            if result == "OK" {
                                DispatchQueue.main.async(){
                                    [unowned self] in
                                    self.performSegue(withIdentifier: "logInAlumno", sender: nil)
                                }
                            }
                            else{
                                logInFallido()
                            }
                        }
                    }
                }
            }
        }
    }
    
    func logInFallido(){
        self.tfEmail.text = ""
        self.tfPassword.text = ""
        let alerta = UIAlertController(title: "Error", message: "El usuario o contraseña son incorrectos", preferredStyle: .alert)
        
        let action = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        
        alerta.addAction(action)
        present(alerta, animated: true, completion: nil)
    }
    
    func logInAlumno(completition: @escaping (String) -> Void){
        var response = ""
        db.collection("Estudiante").getDocuments { [self] querySnapshot, error in
            
            if let error = error {
                self.opc = -1
                print(error.localizedDescription)
                
            }
            else {
                for document in querySnapshot!.documents {
                    let data = document.data()
                
                    
                    if self.tfEmail.text == data["correo"] as! String? &&
                        self.tfPassword.text == data["password"] as! String?{
                        print(tfEmail.text)
                        print(tfPassword.text)
                        //print(String(data["password"]))
                        //print(String(data["correo"]))
                        idUsu = document
                        self.opc = 1
                        response = "OK"
                        completition(response)
                    }
                }
                if self.opc != 1 {
                    response = "Error"
                    completition(response)
                }
            }
        }
    }
    
    func logInCoordi(completition: @escaping (String) -> Void){
        var response = ""
        db.collection("Coordinador").getDocuments { querySnapshot, error in
            
            if let error = error {
                self.opc = -1
                print(error.localizedDescription)
                
            }
            else {
                for document in querySnapshot!.documents {
                    let data = document.data()
                    if self.tfEmail.text == data["correo"] as! String? &&
                        self.tfPassword.text == data["password"] as! String?{
                        self.idUsu = document
                        self.opc = 2
                        response = "OK"
                        completition(response)
                        
                    }
                }
                if self.opc != 2 {
                    response = "Error"
                    completition(response)
                }
            }
        }
    }
    
    func logInAdmin(completition: @escaping (String) -> Void){
        var response = ""
        db.collection("Administrador").getDocuments { querySnapshot, error in
            
            if let error = error {
                self.opc = -1
                print(error.localizedDescription)
            }
            else {
                for document in querySnapshot!.documents {
                    let data = document.data()
                    
                    
                    if self.tfEmail.text == data["correo"] as! String? &&
                        self.tfPassword.text == data["password"] as! String?{
                        self.idUsu = document
                        self.opc = 3
                        response = "OK"
                        completition(response)
                    }
                }
                if self.opc != 3 {
                    response = "Error"
                    completition(response)
                }
            }
        }
    }
    
    
    @IBAction func verCreditos(_ sender: UIButton) {
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "logInAlumno"{
            let vistaTab = segue.destination as! UITabBarController
            let vista = vistaTab.viewControllers![0] as! AlumnoViewController
            vista.IdUsuario = idUsu
            let vista1 = vistaTab.viewControllers![3] as! PerfilAlumnoViewController
            vista1.IdUsuario = idUsu
        }
        else if segue.identifier == "logInCoord"{
            let vistaTab = segue.destination as! CoordTabBarViewController
            let vista1 = vistaTab.viewControllers![0] as! CoordViewController
            vista1.IdUsuario = idUsu
            let vista = vistaTab.viewControllers![1] as! PerfilCoordiViewController
            vista.IdUsuario = idUsu
        }
        else if segue.identifier == "logInAdmin"{
            let vistaTab = segue.destination as! AdminTabBarViewController
            let vista = vistaTab.viewControllers![1] as! PerfilAdminViewController
            vista.IdUsuario = idUsu
        }
        else if segue.identifier == "creditos"{
            let vistaCreds = segue.destination as! CreditosViewController
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
