//
//  ViewController.swift
//  PrepaNetApp_Storyboard
//
//  Created by Soeun Park on 08/10/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var IniScreen: UIView!
    @IBOutlet weak var iniPhoto: UIImageView!
    
    private let imageView: UIImageView = {
        let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 375, height: 667))
        imageView.image = UIImage(named: "main")
        return imageView
    }()

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.portrait
    }
    
    override var shouldAutorotate: Bool {
        return false
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(imageView)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        imageView.center = view.center
        UIView.animate(withDuration: 0.8, animations: {
            self.imageView.alpha = 0.7
        })
        UIView.animate(withDuration: 0.5, animations: {
            self.imageView.alpha = 0.5
        })
        UIView.animate(withDuration: 0.3, animations: {
            self.imageView.alpha = 0.2
        })
        DispatchQueue.main.asyncAfter(deadline: .now()+1, execute: {
            //self.animate()
            self.performSegue(withIdentifier: "iniciar", sender: nil)
        })
        
    }
    
    /*
    private func animate(){
        UIView.animate(withDuration: 1, animations: {
            let size = self.view.frame.size.width * 2
            let diftX = size - self.view.frame.size.width
            let diftY = self.view.frame.size.height - size
            self.imageView.frame = CGRect(
                x: -(diftX/1.5),
                y: diftY/1.5,
                width: size,
                height: size
            )
            
        })
        UIView.animate(withDuration: 1.5, animations: {
            self.imageView.alpha = 0
            
        }, completion: { done in
            if done {
                let viewController = LogInViewController()
                viewController.modalTransitionStyle = .crossDissolve
                viewController.modalPresentationStyle = .fullScreen
                self.present(viewController, animated: true)
            }
            
        })
        
    }
     */

    
}

