//
//  AdminTalleresViewController.swift
//  PrepaNetApp_Storyboard
//
//  Created by untittle on 25/11/22.
//

import UIKit
import Firebase

class AdminTalleresViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    let db = Firestore.firestore()
    
    var tallerMostrar : Seccion!
    var seccionAlumno : String!
    
    
    var listaSecciones = [Seccion]() // Aquí guardé las secciones
    var IdUsuario : QueryDocumentSnapshot!
    var campusSel : String!
    
    @IBOutlet weak var tableView: UITableView!
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.portrait
    }
    
    override var shouldAutorotate: Bool {
        return false
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //campusAdmin = data["campus"] as? String
        //let data = IdUsuario.data()
        //seccionAlumno = data["seccion"] as? String
        
        // Do any additional setup after loading the view.
        getSecciones()
    }
    
    func getSecciones() {
        
        var arrSecciones = [Seccion]()
        
        db.collection("Seccion").getDocuments { querySnapshot, error in
            
            if let error = error {
                print(error.localizedDescription)
            }
            else {
                for document in querySnapshot!.documents {
                    let data = document.data()
                    var campus = data["campus"] as! String
                    
                    // si el campus seleccionado es igual que el campus de la seccion se guarda en el arreglo
                    if self.campusSel == campus {
                        let ident = document.documentID
                        let idSeccion = data["ID"] as! String
                        let idTaller = data["IDTaller"] as! Int
                        campus = data["campus"] as! String
                        let periodo = data["periodo"] as! String
                        let anioInicio = data["anioInicio"] as! Int
                        let mesInicio = data["mesInicio"] as! Int
                        let diaInicio = data["diaInicio"] as! Int
                        let anioFinal = data["anioFinal"] as! Int
                        let mesFinal = data["mesFinal"] as! Int
                        let diaFinal = data["diaFinal"] as! Int
                        
                        let unaSeccion = Seccion(ID: idSeccion, IDTaller: idTaller, periodo: periodo, campus: campus, añoInicio: anioInicio, mesInicio: mesInicio, diaInicio: diaInicio, añoFinal: anioFinal, mesFinal: mesFinal, diaFinal: diaFinal)
                        
                        arrSecciones.append(unaSeccion)
                    }
                    self.listaSecciones = arrSecciones
                    self.tableView.reloadData()
                }
            }
            
        }
        
    }
    
    // MARK: - Table view data source
    
    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return listaSecciones.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celdaTalleres", for: indexPath)
        
        cell.backgroundColor = UIColor(red: 0.082, green: 0.106, blue: 0.188, alpha: 1.0)
        
        cell.textLabel?.textColor = .white
        
        cell.textLabel?.text = listaSecciones[indexPath.row].ID
        
        return cell
    }
    
    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "tablaAlumno"{
            let vistaAlum = segue.destination as! AdminAlumnosViewController
            //let vistaPrueba = segue.destination as! AdminEditarViewController
            let indice = tableView.indexPathForSelectedRow
            
            
            vistaAlum.alumnoSeccion = self.seccionAlumno
            vistaAlum.alumnoCampus = self.campusSel
            vistaAlum.seccionSel = listaSecciones[indice!.row].ID
            
            vistaAlum.campusSel = campusSel
            
        }
        
    }
    
    @IBAction func backbutton(_ sender: UIButton) {
        dismiss(animated: true)
    }
    
}

    

