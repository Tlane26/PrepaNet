//
//  AdminEditarAlumViewController.swift
//  PrepaNetApp_Storyboard
//
//  Created by untittle on 29/11/22.
//

import UIKit
import Firebase
/*
class FirebaseManager {
   static let shared = FirebaseManager()
   private let reference = db.database().reference()
}
// MARK: - Removing functions
extension FirebaseManager {
   public func removePost(withID: String) {
     
         let reference = self.reference.child("Posts").child(withID)
         reference.removeValue { error, _ in
            print(error.localizedDescription)
         }
   }
}
*/
class AdminEditarAlumViewController: UIViewController {
    
    let db = Firestore.firestore()
    
    //var infoInscrito : QueryDocumentSnapshot?
    var listaEstudiantes = [Estudiante]()
    var listaInscritos = [Inscritos]()
    
    var seccionEstablecida : String!
    var campusEstablecido : String!
    
    
    @IBOutlet weak var tfNombre: UITextField!
    @IBOutlet weak var tfApellido: UITextField!
    @IBOutlet weak var tfCorreo: UITextField!
    
    @IBOutlet weak var btnAgregar: UIButton!
    @IBOutlet weak var btnEliminar: UIButton!
    @IBOutlet weak var btnGuardar: UIButton!
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.portrait
    }
    
    override var shouldAutorotate: Bool {
        return false
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        getEstudiantes()
        //getInscritos()
    }
    
    func getEstudiantes() {
        
        var arrEstudiantes = [Estudiante]()
        
        db.collection("Estudiante").getDocuments { querySnapshot, error in
            
            if let error = error {
                print(error.localizedDescription)
            }
            else {
                for document in querySnapshot!.documents {
                    let data = document.data()
                    let correo = data["correo"] as! String
                    if correo == self.tfCorreo.text {
                        let ident = document.documentID
                        let nombre = data["nombre"] as! String
                        let apellido = data["apellido"] as! String
                        let matEst = data["matricula"] as! String
                        let campus = data["campus"] as! String
                        let password = data["password"] as! String
                        let cursoActual = data["cursoActual"] as! String
                        let seccion = data["seccion"] as! [String]
                        
                        let unEstudiante = Estudiante(nombre: nombre, apellido: apellido, matricula: matEst, correo: correo, password: password, cursoActual: cursoActual, campus: campus, seccion: seccion)
                        
                        arrEstudiantes .append(unEstudiante)
                    }
                    
                    self.listaEstudiantes = arrEstudiantes
                }
            }
        }
    }
    
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
    @IBAction func agregarAlumno(_ sender: UIButton) {
        if self.tfCorreo.text == "" || self.tfNombre.text == "" || self.tfApellido.text == "" {
            let alerta = UIAlertController(title: "Error", message: "Introduce los datos", preferredStyle: .alert)
            
            let action = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            
            alerta.addAction(action)
            self.present(alerta, animated: true, completion: nil)
            
        }
        else{
            let newDocument = db.collection("Inscripcion").document()
            newDocument.setData(["matEstudiante": "", "seccion": seccionEstablecida, "periodo": "", "estatus": "Cursando", "nombre": tfNombre.text, "apellido": tfApellido.text, "calificacion": "NA", "campus": campusEstablecido])
            //print(listaEstudiantes)
            
            //let vista = presentingViewController as! AdminEditarViewController
            //vista.llamarReload()
            
            let alerta = UIAlertController(title: "Éxito", message: "Se ha inscrito al alumno/a", preferredStyle: .alert)
            
            let action = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            
            alerta.addAction(action)
            self.present(alerta, animated: true, completion: nil)
            
            tfCorreo.text = ""
            tfNombre.text = ""
            tfApellido.text = ""
            
            
            
        }
    }

    @IBAction func eliminarAlumno(_ sender: UIButton) {
        if self.tfCorreo.text == "" || self.tfNombre.text == "" || self.tfApellido.text == "" {
            let alerta = UIAlertController(title: "Error", message: "Introduce los datos", preferredStyle: .alert)
            
            let action = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            
            alerta.addAction(action)
            self.present(alerta, animated: true, completion: nil)
            
        }
        else{
            
            
            db.collection("Inscripcion").getDocuments { [self] querySnapshot, error in
                
                if let error = error{
                    print(error.localizedDescription)
                }
                else {
                    for document in querySnapshot!.documents {
                        let data = document.data()
                    
                        if self.tfNombre.text == data["nombre"] as! String? &&
                            self.tfApellido.text == data["apellido"] as! String?{
                            
                            db.collection("Inscripcion").document(document.documentID).delete()
                            
                        }
                    }
                }
            }
            
            let alerta = UIAlertController(title: "Éxito", message: "Se ha desinscrito al alumno/a", preferredStyle: .alert)
            
            let action = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            
            alerta.addAction(action)
            self.present(alerta, animated: true, completion: nil)
            
            tfCorreo.text = ""
            tfNombre.text = ""
            tfApellido.text = ""
        }
        
    }
    
    @IBAction func guardarCambios(_ sender: UIButton) {
        let alerta = UIAlertController(title: "Éxito", message: "Los cambios fueron realizados", preferredStyle: .alert)
        
        let action = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        
        alerta.addAction(action)
        self.present(alerta, animated: true, completion: nil)
    }
    
    
    @IBAction func backButton(_ sender: UIButton) {
        dismiss(animated: true)
    }
    
    
}

