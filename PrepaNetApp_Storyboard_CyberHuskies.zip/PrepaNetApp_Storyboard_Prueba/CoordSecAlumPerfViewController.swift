//
//  CoordSecAlumPerfViewController.swift
//  PrepaNetApp_Storyboard
//
//  Created by untittle on 18/11/22.
//

import UIKit
import Firebase

class CoordSecAlumPerfViewController: UIViewController {
    
    var infoEstudiante : QueryDocumentSnapshot!
    
    @IBOutlet weak var imgPerfil: UIImageView!
    @IBOutlet weak var lbNombre: UILabel!
    @IBOutlet weak var lbCorreo: UILabel!
    @IBOutlet weak var lbCalificacion: UILabel!
    @IBOutlet weak var lbProgreso: UILabel!
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.portrait
    }
    
    override var shouldAutorotate: Bool {
        return false
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let data = infoEstudiante.data()
        
        lbNombre.text = (data["nombre"] as! String) + " " + (data["apellido"] as! String)
        lbCorreo.text = data["matEstudiante"] as? String
        lbCalificacion.text = data["calificacion"] as? String
        lbProgreso.text = data["estatus"] as? String
    }
    

    @IBAction func backbutton(_ sender: UIButton) {
        dismiss(animated: true)
        //self.performSegue(withIdentifier: "regresar", sender: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
