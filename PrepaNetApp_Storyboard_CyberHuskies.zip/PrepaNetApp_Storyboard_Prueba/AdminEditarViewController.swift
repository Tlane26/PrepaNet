//
//  AdminEditarViewController.swift
//  PrepaNetApp_Storyboard
//
//  Created by untittle on 28/11/22.
//

import UIKit
import Firebase

class AdminEditarViewController: UIViewController {
    
    let db = Firestore.firestore()
    var campus : String!
    var seccion : String!
    
    var campusSel : String!
    var seccionSel : String!
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.portrait
    }
    
    override var shouldAutorotate: Bool {
        return false
    }
    
    // campus
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "fechar"{
            let vistaEditar = segue.destination as! FecharViewController
            //let vistaPrueba = segue.destination as! AdminEditarViewController
            vistaEditar.Fseccion = seccion
            vistaEditar.Fcampus = campus
            
        }
        else if segue.identifier == "alumnosE"{
            let vistaEditarA = segue.destination as! AdminEditarAlumViewController
            
            vistaEditarA.campusEstablecido = campusSel
            vistaEditarA.seccionEstablecida = seccionSel
            //let vistaPrueba = segue.destination as! AdminEditarViewController
            //vistaEditarA.Fseccion = seccion
            //vistaEditarA.Fcampus = campus
            
        }
    }
    
    @IBAction func backButton(_ sender: UIButton) {
        dismiss(animated: true)
    }
    
    /*
    func llamarReload(){
        let vista = presentingViewController as! AdminAlumnosViewController
        vista.reloadTabla()
    }*/
}
