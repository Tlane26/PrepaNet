//
//  AdminViewController.swift
//  PrepaNetApp_Storyboard
//
//  Created by Eduardo salazar on 21/10/22.
//

import UIKit
import Firebase

class AdminViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{
    
    // Prueba
    //let VCalum = storyboard.instantiateViewController(withIdentifier: "AdminEditarAlumViewController") as! AdminEditarAlumViewController
    // Termina
    
    let db = Firestore.firestore()
    
    var listaCampus = [String]()
    var listaSecciones = [Seccion]()
    
    var IdUsuario : QueryDocumentSnapshot!
    var campusAdmin: String!
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.portrait
    }
    
    override var shouldAutorotate: Bool {
        return false
    }
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

       getCampus()
    }
    
    func getCampus(){
        var arrCampus = [String]()
        db.collection("Campus").getDocuments{ querySnapshot, error in
            
            if let error = error {
                print(error.localizedDescription)
            }
            else{
                for document in querySnapshot!.documents{
                    let data = document.data()
                    let nombre = data["nombre"] as! String
                    print(nombre)
                    arrCampus.append(nombre)
                }
                self.listaCampus = arrCampus
                self.tableView.reloadData()
            }
        }
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //return listaSecciones.count
        return listaCampus.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celdaCampus", for: indexPath)
        
        cell.backgroundColor = UIColor(red: 0.082, green: 0.106, blue: 0.188, alpha: 1.0)
        
        cell.textLabel?.textColor = .white

        // Configure the cell...
        cell.textLabel?.text = listaCampus[indexPath.row]
        
        return cell
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        let vistaTalleres = segue.destination as! AdminTalleresViewController
        let indice = tableView.indexPathForSelectedRow
        vistaTalleres.campusSel = listaCampus[indice!.row]  // campus seleccionado
        
        }
     
}
