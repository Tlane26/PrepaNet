//
//  alumnoAdminisViewController.swift
//  PrepaNetApp_Storyboard
//
//  Created by Eduardo salazar on 28/11/22.
//

import UIKit
import Firebase

class alumnoAdminisViewController: UIViewController {

    //var infoEstudiante : QueryDocumentSnapshot!
    
    var matricula : String!
    let db = Firestore.firestore()
    
    @IBOutlet weak var lblnombre: UILabel!
    @IBOutlet weak var lblmatricula: UILabel!
    @IBOutlet weak var lblestado: UILabel!
    @IBOutlet weak var lblcalifi: UILabel!
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.portrait
    }
    
    override var shouldAutorotate: Bool {
        return false
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        info()
         
    }
    
    func info(){
        
        db.collection("Inscripcion").getDocuments { querySnapshot, error in
            
            if let error = error {
                print(error.localizedDescription)
            }
            else {
                for document in querySnapshot!.documents {
                    let data = document.data()
                    
                    let matEst = data["matEstudiante"] as! String
                    if self.matricula == matEst{
                        
                        let ident = document.documentID
                        let estatus = data["estatus"] as! String
                        let nombre = data["nombre"] as! String
                        let apellido = data["apellido"] as! String
                        let calificacion = data["calificacion"] as! String
                        
                        self.lblnombre.text = nombre + " " + apellido
                        self.lblmatricula.text = matEst
                        self.lblcalifi.text = calificacion
                        self.lblestado.text = estatus
                        
                     
                    }
                    
                }
                
            }
            
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    @IBAction func backbutton(_ sender: UIButton) {
        dismiss(animated: true)
    }
    
}
