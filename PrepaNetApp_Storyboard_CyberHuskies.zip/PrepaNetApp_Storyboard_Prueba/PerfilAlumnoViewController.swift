//
//  PerfilAlumnoViewController.swift
//  PrepaNetApp_Storyboard
//
//  Created by Eduardo salazar on 02/11/22.
//

import UIKit
import Firebase

class PerfilAlumnoViewController: UIViewController {

    var IdUsuario : QueryDocumentSnapshot!
    
    
    @IBOutlet weak var lblNombre: UILabel!
    @IBOutlet weak var correo: UILabel!
    @IBOutlet weak var lbCampus: UILabel!
    @IBOutlet weak var textButtonTaller: UIButton!
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.portrait
    }
    
    override var shouldAutorotate: Bool {
        return false
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let data = IdUsuario.data()
        
        lblNombre.text = (data["nombre"] as! String) + " " + (data["apellido"] as! String)
        correo.text = data["correo"] as! String
        lbCampus.text = "Campus: " + (data["campus"] as! String)
        
        textButtonTaller.setTitle("Progreso", for: .normal)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    @IBAction func cerrarSesion(_ sender: UIButton) {
        let vista = presentingViewController as! LogInViewController
        vista.tfPassword.text = ""
        vista.tfEmail.text = ""
        dismiss(animated: true)
    }
    
}
