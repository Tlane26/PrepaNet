//
//  Inscritos.swift
//  PrepaNetApp_Storyboard
//
//  Created by untittle on 18/11/22.
//

import UIKit

class Inscritos: Codable {
    
    var matEstudiante : String
    var seccion : String
    var periodo : String
    var estatus : String
    var nombre : String
    var apellido : String
    var calificacion : String
    
    init(matEstudiante: String, seccion: String, periodo: String, estatus: String, nombre: String, apellido: String, calificacion: String) {
        self.matEstudiante = matEstudiante
        self.seccion = seccion
        self.periodo = periodo
        self.estatus = estatus
        self.nombre = nombre
        self.apellido = apellido
        self.calificacion = calificacion
    }

}
