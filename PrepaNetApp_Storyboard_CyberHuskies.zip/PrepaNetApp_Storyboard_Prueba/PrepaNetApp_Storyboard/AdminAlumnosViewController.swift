//
//  AdminAlumnosViewController.swift
//  PrepaNetApp_Storyboard
//
//  Created by untittle on 28/11/22.
//

import UIKit
import Firebase

class AdminAlumnosViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    let db = Firestore.firestore()
    
    var infoInscrito : QueryDocumentSnapshot?
    var listaInscritos = [Inscritos]()
    var alumnoSeccion : String!
    var alumnoCampus : String!
    var seccionSel : String!
    var campusSel : String!

    @IBOutlet weak var tableView: UITableView!
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.portrait
    }
    
    override var shouldAutorotate: Bool {
        return false
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        getInscritos()
    }
    
    func getInscritos() {
        
        var arrInscritos = [Inscritos]()
        
        db.collection("Inscripcion").getDocuments { querySnapshot, error in
            
            if let error = error {
                print(error.localizedDescription)
            }
            else {
                for document in querySnapshot!.documents {
                    let data = document.data()
                    
                    let campus = data["campus"] as! String
                    // Checar que los inscritos sean de la seccion escogida 
                    var seccion = data["seccion"] as! String
                    // campus
                    if self.alumnoCampus == campus && seccion == self.seccionSel{
                        
                        let ident = document.documentID
                        let matEst = data["matEstudiante"] as! String
                         seccion = data["seccion"] as! String
                        let periodo = data["periodo"] as! String
                        let estatus = data["estatus"] as! String
                        let nombre = data["nombre"] as! String
                        let apellido = data["apellido"] as! String
                        let calificacion = data["calificacion"] as! String
                        
                        let unInscrito = Inscritos(matEstudiante: matEst, seccion: seccion, periodo: periodo, estatus: estatus, nombre: nombre, apellido: apellido, calificacion: calificacion)
                        
                        arrInscritos .append(unInscrito)
                        
                        self.infoInscrito = document
                    }
                    self.listaInscritos = arrInscritos
                    self.tableView.reloadData()
                    
                }
                
            }
            
        }
        
    }
    
    // MARK: - Table view data source

    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return listaInscritos.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celdaA", for: indexPath)
        
        cell.backgroundColor = UIColor(red: 0.082, green: 0.106, blue: 0.188, alpha: 1.0)
        
        cell.textLabel?.textColor = .white

        // Configure the cell...
        cell.textLabel?.text = listaInscritos[indexPath.row].nombre + " " + listaInscritos[indexPath.row].apellido

        return cell
    }
    
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "alumno"{
            let vistaEditar = segue.destination as! alumnoAdminisViewController
            let indice = tableView.indexPathForSelectedRow
            
            vistaEditar.matricula = listaInscritos[indice!.row].matEstudiante
        }
        else{
            let vistaEditar = segue.destination as! AdminEditarViewController
            //let vistaPrueba = segue.destination as! AdminEditarViewController
            vistaEditar.seccion = alumnoSeccion
            vistaEditar.campus = alumnoCampus
            vistaEditar.campusSel = campusSel
            vistaEditar.seccionSel = seccionSel
        }
        
    
    }
    

    
    @IBAction func back(_ sender: UIButton) {
        dismiss(animated: true)
    }
    
    /*
    func reloadTabla(){
        tableView.reloadData()
    }*/
    
}
