//
//  Administrador.swift
//  PrepaNetApp_Storyboard
//
//  Created by Eduardo salazar on 21/10/22.
//

import UIKit

class Administrador: Codable {
    
    var nombre : String
    var apellido : String
    var correo : String
    var password : String

}
