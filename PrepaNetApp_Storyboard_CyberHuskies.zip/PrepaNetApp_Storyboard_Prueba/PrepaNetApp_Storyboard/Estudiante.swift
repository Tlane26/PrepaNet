//
//  Estudiante.swift
//  PrepaNetApp_Storyboard
//
//  Created by Eduardo salazar on 21/10/22.
//

import UIKit

class Estudiante: Codable {
    
    //var ident : String
    var nombre : String
    var apellido : String
    var matricula : String
    var correo : String
    var password : String
    var cursoActual : String
    var campus : String
    var seccion : [String]
    
    init(nombre: String, apellido: String, matricula: String, correo: String, password: String, cursoActual: String, campus: String, seccion: [String]) {
        self.nombre = nombre
        self.apellido = apellido
        self.matricula = matricula
        self.correo = correo
        self.password = password
        self.cursoActual = cursoActual
        self.campus = campus
        self.seccion = seccion
    }
}
